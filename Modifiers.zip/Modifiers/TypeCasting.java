package Modifiers;

public class TypeCasting {
	public float areaOfRhombus(int a,int b)
	{
		int v=a*b;
		float value=(float)v;
		return value;
	}
	public int areaOfCircle(float radius)
	{
		float ans=3.14f*radius*radius;
		int value=(int)ans;
		return value;
	}
	public float areaOfRectangle(int len,int breadth)
	{
		int area=len*breadth;
		float ans=(float)area;
		return ans;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TypeCasting tc=new TypeCasting();
		float radius = 2.2f;
		System.out.println("Area of circle : "+tc.areaOfCircle(radius));
		
	}

}
