package Modifiers;

public class StringsAssignment {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
		String t="Delhi";
		String o="Mumbai";
		String k="delhi";
		String y=new String ("Mumbai");
		String l=new String("delhi");
		String p=new String("Hello");
		
		System.out.println(t.equals(l));
		
		
	}

}