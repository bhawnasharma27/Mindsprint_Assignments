package Modifiers;

public class prime_number {

	public boolean isPrime(int a)
	{
		if(a<=1) return false;
		for(int i=2;i<a/2;i++) {
			if(a%i==0) return false;
			
		}
		return true;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		prime_number obj=new prime_number();
		System.out.println("Is this prime : "+obj.isPrime(15));
	}

}
