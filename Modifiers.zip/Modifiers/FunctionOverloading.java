package Modifiers;

public class FunctionOverloading {
	public void area(int a,int b)
	{
		System.out.println("The area is : "+(a+b));
	}
	float area(float radius)
	{
		System.out.print("The area of circle is : ");
		float result=3.14f*radius*radius;
		return result;
	}
	public void area(int x,int y,int z)
	{
		System.out.println("The area2 is : "+(y+x+z));
	}
	public static void main(String[] args)
	{
		FunctionOverloading fo=new FunctionOverloading();
		float y=fo.area(2.5f);
		System.out.println(y);
		float num1=2.0f;
		int num2=(int) num1;
		fo.area(num2,3);
		fo.area(3,5,6);
		
		
		
		
	}
}
