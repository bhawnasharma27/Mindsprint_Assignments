package Modifiers;

public class Even_number {
	public boolean isEven(int a)
	{
		if(a%2==0) return true;
		else return false;
	}
	public static void main(String[] args) {
		Even_number obj =new Even_number();
		System.out.println("Is Even : "+obj.isEven(9));
	}
}
