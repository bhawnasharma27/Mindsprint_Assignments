package Modifiers;
abstract class Animal
{
	abstract void sound();
	public void bark()
	{
		System.out.println("Bark...");
	}
}
class dog extends Animal
{
	void sound()
	{
		System.out.println("Sound...");
	}
}
public class Abstract_class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dog obj=new dog();
		obj.sound();
		obj.bark();
		
	}

}
