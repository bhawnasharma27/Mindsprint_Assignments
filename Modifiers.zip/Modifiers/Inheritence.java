package Modifiers;
class product
{
	int id=8;
	String name="Amul";
	public void display()
	{
		System.out.println("Name : "+name+" id : "+id);
	}
}
class A extends product
{
	int count=50;
	String category="butter";
	public void displayall()
	{
		display();
		System.out.println("Count : "+count+" category : "+category);
	}
}
class B extends product
{
	int count=60;
	String category="milk";
	public void displayall()
	{
		display();
		System.out.println("Count : "+count+" category : "+category);
	}
}
class C extends product
{
	int count=10;
	String category="curd";
	public void displayall2()
	{display();
		System.out.println("Count : "+count+" category : "+category);
	}
}
class subA extends A
{
	int price=50;
	int total=count*price;
	public void displayall2()
	{
		displayall();
		System.out.println("Total : "+total);	
	}
	
}
class subB extends B
{
	int price=25;
	int total=count*price;
	public void displayall2()
	{
		displayall();
		System.out.println("Total : "+total);	
	}
	
}
public class Inheritence {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		subA obj=new subA();
		obj.displayall2();
		subB obj2=new subB();
		obj2.displayall2();
		C obj3=new C();
		obj3.displayall2();
	}
}
