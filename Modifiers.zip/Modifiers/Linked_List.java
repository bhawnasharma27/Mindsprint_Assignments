package Modifiers;
import java.util.*;
public class Linked_List {
	public static void main(String[] args) {
		LinkedList<String> list1=new LinkedList<>();
		list1.add("may");
		list1.add("june");
		list1.add("july");
		list1.add("august");
		list1.add("april");
		list1.add("november");
		//adding elements
		list1.addLast("december");
		list1.addFirst("january");
		list1.add("march");
		list1.add(1,"february");
		System.out.println("list is : "+list1);
		
		
		list1.remove("march");
		list1.add(2,"march");
		list1.remove("april");
		list1.add(3,"april");
		
		list1.add(8,"september");
		list1.add(9,"october");
		System.out.println("list after sorting : "+list1);
		
		System.out.print("even months: ");
		for(int i=0;i<12;i++) {
			if(i%2==0)
			{
				System.out.print(list1.get(i)+" ");
			}
		}
		System.out.println("");
		
		System.out.print("odd months: ");
		for(int i=0;i<12;i++) {
			if(i%2!=0)
			{
				System.out.print(list1.get(i)+" ");
			}
		}
		System.out.println("");
		System.out.println("first month : "+list1.get(0)+" , last month : "+list1.get(11));
		list1.remove("august");
		System.out.println("After removing birthday month list is: "+list1);
		boolean winter=false;
		for(int i=0;i<12;i++)
		{
			if(list1.get(i)=="november"||list1.get(i)=="december"||list1.get(i)=="january"||list1.get(i)=="february")
			{
				winter=true;
				break;
			}
		}
		System.out.println("is there any winter month : "+winter);
		System.out.println("first month : "+list1.peekFirst());
		System.out.println("last month : "+list1.peekLast());
		list1.pollFirst();
		list1.pollLast();
		System.out.println("final list : "+list1);
		
	}
}
