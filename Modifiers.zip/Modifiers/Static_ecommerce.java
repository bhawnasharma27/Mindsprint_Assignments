package Modifiers;

public class Static_ecommerce {

	class ecommerece{
		int prod_id,price,discount;
		String name;
		ecommerece()
		{
			prod_id=2;
			price=4000;
			discount=5;
			name="Diva";
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
