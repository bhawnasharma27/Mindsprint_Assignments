package Modifiers;
import java.util.*;
public class Hash_Set {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet hs = new LinkedHashSet();
		 hs.add(1);
		 hs.add(34);
		 hs.add(3.2f);
		 hs.add(2.0f);
		 hs.add('a');
		 hs.add('b');
		 hs.add(true);
		 System.out.println("list 1 : "+hs);
		 Scanner sc=new Scanner(System.in);
		 
		 LinkedHashSet<Integer>hsnew=new LinkedHashSet<>();
		 
		for(int i=1;i<=10;i++)
		{
			int value=sc.nextInt();
			hsnew.add(value);
		}
		System.out.println("new hashSet" + hsnew);
		 
		 
	}

}
