package Modifiers;

public class Simple_interest {
	public float calculateSI(int amount,int principle,float interest)
	{
		float value=(amount*principle*interest)/100;
		return value;
	}
	public static void main(String[] args)
	{
		Simple_interest mf=new Simple_interest();
		int a=5000,p=100;
		float i=0.5f;
		float val=mf.calculateSI(a,p,i);
		System.out.println(val);
	}
	
}
