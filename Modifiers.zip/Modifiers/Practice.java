package Modifiers;
import java.util.Scanner;
public class Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=0;
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("enter your number");
			num=sc.nextInt();
			System.out.println("here is your number : "+num);
		}while(num>=1);
		System.out.println("your code ends here...");
	}

}
