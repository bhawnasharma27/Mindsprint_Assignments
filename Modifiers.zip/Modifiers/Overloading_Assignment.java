package Modifiers;

public class Overloading_Assignment {

	public int calculator(int a,int b)
	{
		return a+b;
	}
	public float calculator(float a,float b)
	{
		if(a>b)
		return a-b;
		else
		return b-a; 
	}
	public float calculator(int a,int b,float c)
	{
		return a*b*c;
	}
	public static void main(String[] args) {
		{
			int a=5,b=8;
			float c=4.3f,d=2.3f;
			Overloading_Assignment obj=new Overloading_Assignment();
			System.out.println(obj.calculator(a,b));
			System.out.println(obj.calculator(c,d));
			System.out.println(obj.calculator(a, b,c));
		}
}}
