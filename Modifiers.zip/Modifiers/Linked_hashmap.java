package Modifiers;
import java.util.*;

public class Linked_hashmap {
	public static void main(String[] args) {
	LinkedHashMap<Integer,String> lhm=new LinkedHashMap<>();
	Scanner sc=new Scanner(System.in);
	for(int i=0;i<10;i++)
	{
//		System.out.println("Enter code: ");
//		int code=sc.nextInt();
		System.out.println("Enter name: ");
		String country_name=sc.nextLine();
		
		lhm.put(i,country_name);
	}
	System.out.println(lhm);
	}
	

		
}
