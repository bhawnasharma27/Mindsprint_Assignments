package Modifiers;
import java.util.*;
public class Array_List {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>al= new ArrayList();
		System.out.println("Enter 6 fruits : ");
		Scanner sc=new Scanner(System.in);
		for(int i=1;i<=6;i++)
		{
			al.add(sc.nextLine());
		}
		System.out.println(al);
		System.out.println("Enter Two cities : ");
		for(int i=1;i<=2;i++)
		{
			al.add(sc.nextLine());
		}
		System.out.println("Enter 2 hobbies: ");
		for(int i=1;i<=2;i++)
		{
			al.add(sc.nextLine());
		}
		System.out.println(al);
		al.remove(3);
		System.out.println(al);
		boolean ifcon=al.contains("cricket");
		System.out.println("Cricket status : "+ifcon);
		System.out.println("4th and 5th element are : "+al.get(3)+" , "+al.get(5));
		int index=al.indexOf("singing");
		al.set(index, "dancing");
		System.out.println("final array : "+al);
		Collections.reverse(al);
		System.out.println("final array : "+al);
		al.add(3,"kerala");
		System.out.println("final array : "+al);
		
		
		
	}

}
